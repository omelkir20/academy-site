export default function Loading() {
  return (
    <div className="container mx-auto px-4 py-10 animate-pulse">
      <div className="h-8 bg-gray-200 rounded-xl w-1/3 mb-2" />
      <div className="h-4 bg-gray-100 rounded-xl w-1/2 mb-8" />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="rounded-2xl border bg-white overflow-hidden">
            <div className="h-44 bg-gradient-to-br from-gray-200 to-gray-100" />
            <div className="p-5 space-y-3">
              <div className="h-3 bg-gray-200 rounded-full w-1/4" />
              <div className="h-4 bg-gray-200 rounded-full" />
              <div className="h-3 bg-gray-100 rounded-full w-3/4" />
              <div className="h-3 bg-gray-100 rounded-full w-1/2" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
